
import { GoogleGenAI, Type } from "@google/genai";
import { ProjectConfig, GeneratedPlan } from '../types';

const getClient = () => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    throw new Error("API Key not found in environment");
  }
  return new GoogleGenAI({ apiKey });
};

export const generateFloorPlan = async (config: ProjectConfig): Promise<GeneratedPlan> => {
  const ai = getClient();

  // Construct a culturally aware sub-prompt
  let culturalDirectives = "";
  if (config.culturalSystem.includes("Vastu")) {
    culturalDirectives = `
      - **Master Bedroom**: Strongly prefer South-West (SW) quadrant (Earth element).
      - **Kitchen**: Strongly prefer South-East (SE) (Fire element) or North-West (NW).
      - **Entrance**: Prefer North or East facing.
      - **Center**: Keep the Brahmasthan (center of plot) relatively open or as a hall/circulation.
      - **Water/Bath**: Avoid NE for toilets.
    `;
  } else if (config.culturalSystem === 'Islamic Beliefs') {
    culturalDirectives = `
      - **Privacy**: Ensure visual screening for living areas from the entrance.
      - **Toilets**: Should not face towards Qibla.
    `;
  }

  const prompt = `
    Act as a Senior Principal Architect. Design a technical, code-compliant floor plan.
    
    **Project Specs**:
    - Type: ${config.projectType}
    - Plot: ${config.width}m (Width) x ${config.depth}m (Depth)
    - Authority: ${config.municipalCode}
    - Requirements: ${config.requirements.join(', ')}
    - Preferences: ${config.adjacency}

    **ARCHITECTURAL EXECUTION PROTOCOL (Chain of Thought)**:
    
    **PHASE 1: SITE ZONING (Mandatory)**
    1. **Total Canvas**: You MUST account for exactly ${config.width * config.depth} sq. meters. Coordinates (0,0) to (${config.width},${config.depth}).
    2. **Setbacks**: Apply mandatory setbacks based on ${config.municipalCode} (typically 1m-2m on sides/rear, 2-3m front).
    3. **Categorization**: 
       - The area *inside* setbacks is the 'Buildable Envelope'.
       - The area *outside* the envelope (the setbacks) MUST be labeled as 'setback' (for narrow strips) or 'outdoor' (for garden/parking).
    
    **PHASE 2: PROGRAMMATIC SPINE**
    1. **Flow**: Establish a hierarchy: Main Entry -> Foyer -> Living -> Dining -> Kitchen.
    2. **Private Wings**: Place Bedrooms away from direct view of the main entry.
    3. **Circulation**: Connect rooms with 'circulation' zones (corridors/halls). Do not leave empty gaps between rooms.
    
    **PHASE 3: DETAILED LAYOUT & FILL**
    1. **100% Coverage Rule**: ABSOLUTELY NO UNDEFINED WHITE SPACE. 
       - If a space is not a room, it is 'circulation'. 
       - If it is outside the building, it is 'outdoor' or 'setback'.
    2. **Wall Thickness**: Assume internal walls share coordinates.
    3. **Features**: Add doors and windows. Ensure doors swing into rooms and don't collide.
    
    **PHASE 4: CULTURAL & REGULATORY CHECK**
    1. Apply these Cultural Rules: ${culturalDirectives}
    2. Check Minimum Dimensions: Bed > 9m², Kitchen > 5m².
    3. **Guidance**: For EACH room, provide a 'guidance' string explaining what furniture to keep where and why (e.g. "Place bed head towards South for Vastu").
    
    **Output**:
    Generate a JSON object representing this plan. 
    - Include a 'designLog' array explaining your key decisions (e.g., "Placed Kitchen in SE for Vastu compliance", "Created 2m front setback for parking").
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          designLog: {
             type: Type.ARRAY,
             items: { type: Type.STRING },
             description: "List of architectural decisions and reasoning steps."
          },
          rooms: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                name: { type: Type.STRING },
                type: { 
                  type: Type.STRING, 
                  enum: ["room", "circulation", "outdoor", "setback", "service"],
                  description: "Classifies the space. 'room' has walls. 'setback'/'outdoor' is open to sky."
                },
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER },
                width: { type: Type.NUMBER },
                height: { type: Type.NUMBER },
                features: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                      type: { type: Type.STRING, enum: ["door", "window", "opening"] },
                      wall: { type: Type.STRING, enum: ["top", "bottom", "left", "right"] },
                      position: { type: Type.NUMBER },
                      width: { type: Type.NUMBER }
                    },
                    required: ["type", "wall", "position", "width"]
                  }
                },
                guidance: { 
                  type: Type.STRING,
                  description: "Specific advice on furniture placement, items to keep, and cultural/Vaastu compliance for this room." 
                }
              },
              required: ["id", "name", "type", "x", "y", "width", "height", "features"]
            }
          },
          totalArea: { type: Type.NUMBER, description: "Should match width * depth" },
          builtUpArea: { type: Type.NUMBER, description: "Sum of room + circulation + service areas" },
          plotCoverageRatio: { type: Type.NUMBER, description: "BuiltUpArea / TotalArea" },
          compliance: {
            type: Type.OBJECT,
            properties: {
              regulatory: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    rule: { type: Type.STRING },
                    status: { type: Type.STRING, enum: ["PASS", "FAIL", "WARN"] },
                    message: { type: Type.STRING },
                    recommendation: { type: Type.STRING }
                  }
                }
              },
              cultural: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    rule: { type: Type.STRING },
                    status: { type: Type.STRING, enum: ["PASS", "FAIL", "WARN"] },
                    message: { type: Type.STRING },
                    recommendation: { type: Type.STRING }
                  }
                }
              }
            }
          },
          bom: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                material: { type: Type.STRING },
                quantity: { type: Type.STRING },
                unit: { type: Type.STRING },
                estimatedCost: { type: Type.NUMBER }
              }
            }
          },
          totalCostRange: {
            type: Type.OBJECT,
            properties: {
              min: { type: Type.NUMBER },
              max: { type: Type.NUMBER }
            }
          }
        }
      }
    }
  });

  const text = response.text;
  if (!text) {
    throw new Error("No response from AI");
  }

  return JSON.parse(text) as GeneratedPlan;
};

export const analyzePlanFromImage = async (base64Image: string): Promise<GeneratedPlan> => {
  const ai = getClient();
  
  const base64Data = base64Image.split(',')[1] || base64Image;

  const prompt = `
    Analyze this architectural floor plan image.
    
    Tasks:
    1. Identify all visible rooms and spaces.
    2. Check for general regulatory compliance (Standard Building Codes) regarding setbacks and natural lighting/ventilation.
    3. Check for general Vaastu Shastra compliance (Orientation of key rooms like Kitchen, Master Bedroom, Entrance).
    4. Provide placement 'guidance' for each room (e.g., "Bed in SW corner").
    5. Estimate a Bill of Materials (BOM).
    
    Output strictly in the specified JSON format.
  `;

  const response = await ai.models.generateContent({
    model: 'gemini-2.5-flash',
    contents: {
      parts: [
        {
          inlineData: {
            mimeType: 'image/jpeg',
            data: base64Data
          }
        },
        { text: prompt }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          designLog: {
             type: Type.ARRAY,
             items: { type: Type.STRING }
          },
          rooms: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                id: { type: Type.STRING },
                name: { type: Type.STRING },
                type: { 
                  type: Type.STRING, 
                  enum: ["room", "circulation", "outdoor", "setback", "service"]
                },
                x: { type: Type.NUMBER },
                y: { type: Type.NUMBER },
                width: { type: Type.NUMBER },
                height: { type: Type.NUMBER },
                features: {
                  type: Type.ARRAY,
                  items: {
                    type: Type.OBJECT,
                    properties: {
                       type: { type: Type.STRING, enum: ["door", "window", "opening"] },
                       wall: { type: Type.STRING, enum: ["top", "bottom", "left", "right"] },
                       position: { type: Type.NUMBER },
                       width: { type: Type.NUMBER }
                    }
                  }
                },
                guidance: { type: Type.STRING }
              },
              required: ["id", "name", "type"]
            }
          },
          totalArea: { type: Type.NUMBER },
          builtUpArea: { type: Type.NUMBER },
          plotCoverageRatio: { type: Type.NUMBER },
          compliance: {
            type: Type.OBJECT,
            properties: {
              regulatory: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    rule: { type: Type.STRING },
                    status: { type: Type.STRING, enum: ["PASS", "FAIL", "WARN"] },
                    message: { type: Type.STRING },
                    recommendation: { type: Type.STRING }
                  }
                }
              },
              cultural: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    rule: { type: Type.STRING },
                    status: { type: Type.STRING, enum: ["PASS", "FAIL", "WARN"] },
                    message: { type: Type.STRING },
                    recommendation: { type: Type.STRING }
                  }
                }
              }
            }
          },
          bom: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                material: { type: Type.STRING },
                quantity: { type: Type.STRING },
                unit: { type: Type.STRING },
                estimatedCost: { type: Type.NUMBER }
              }
            }
          },
          totalCostRange: {
            type: Type.OBJECT,
            properties: {
              min: { type: Type.NUMBER },
              max: { type: Type.NUMBER }
            }
          }
        }
      }
    }
  });
  
  const text = response.text;
  if (!text) throw new Error("No response from AI");
  
  const plan = JSON.parse(text) as GeneratedPlan;
  plan.imageUrl = base64Image;
  return plan;
};