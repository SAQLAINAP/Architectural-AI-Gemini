
import React, { useState, useEffect } from 'react';
import { ViewState, ProjectConfig, GeneratedPlan, SavedProject } from './types';
import Home from './views/Home';
import Configuration from './views/Configuration';
import Dashboard from './views/Dashboard';
import Projects from './views/Projects';
import Documentation from './views/Documentation';
import { generateFloorPlan, analyzePlanFromImage } from './services/geminiService';
import { saveProject } from './services/storageService';
import { Navbar } from './components/NeoComponents';

function App() {
  const [viewState, setViewState] = useState<ViewState>(ViewState.HOME);
  const [config, setConfig] = useState<ProjectConfig | null>(null);
  const [generatedPlan, setGeneratedPlan] = useState<GeneratedPlan | null>(null);
  const [currentProjectId, setCurrentProjectId] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDark, setIsDark] = useState(false);

  useEffect(() => {
    // Check system preference or localStorage
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme === 'dark' || (!savedTheme && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
      setIsDark(true);
      document.documentElement.classList.add('dark');
    } else {
      setIsDark(false);
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const toggleTheme = () => {
    setIsDark(prev => {
      const newTheme = !prev;
      if (newTheme) {
        document.documentElement.classList.add('dark');
        localStorage.setItem('theme', 'dark');
      } else {
        document.documentElement.classList.remove('dark');
        localStorage.setItem('theme', 'light');
      }
      return newTheme;
    });
  };

  const handleGenerate = async (newConfig: ProjectConfig) => {
    setConfig(newConfig);
    setIsProcessing(true);
    setError(null);
    setCurrentProjectId(null); // Reset current ID for new generation
    try {
      const plan = await generateFloorPlan(newConfig);
      setGeneratedPlan(plan);
      setViewState(ViewState.DASHBOARD);
    } catch (err: any) {
      console.error(err);
      setError(err.message || "Failed to generate plan. Please check API key or try again.");
    } finally {
      setIsProcessing(false);
    }
  };

  const handleUploadImage = async (file: File) => {
     setIsProcessing(true);
     setError(null);
     setCurrentProjectId(null);
     
     const reader = new FileReader();
     reader.onload = async () => {
       try {
         const base64 = reader.result as string;
         const plan = await analyzePlanFromImage(base64);
         setGeneratedPlan(plan);
         setViewState(ViewState.DASHBOARD);
       } catch (err: any) {
         console.error(err);
         setError(err.message || "Failed to analyze image.");
       } finally {
         setIsProcessing(false);
       }
     };
     reader.onerror = () => {
       setError("Failed to read file.");
       setIsProcessing(false);
     };
     reader.readAsDataURL(file);
  };

  const handleSaveProject = () => {
    if (generatedPlan) {
      const name = prompt("Enter a name for your project:", "My Dream House");
      if (!name) return;

      const newProject: SavedProject = {
        id: currentProjectId || crypto.randomUUID(),
        name: name,
        date: new Date().toISOString(),
        config: config,
        plan: generatedPlan
      };

      saveProject(newProject);
      setCurrentProjectId(newProject.id);
      alert("Project saved successfully!");
    }
  };

  const handleLoadSavedProject = (project: SavedProject) => {
    setConfig(project.config);
    setGeneratedPlan(project.plan);
    setCurrentProjectId(project.id);
    setViewState(ViewState.DASHBOARD);
  };

  // Deprecated single-save loader, mapped to dashboard for now if needed, but we prefer Projects view
  const handleLegacyLoad = () => {
     setViewState(ViewState.PROJECTS);
  };

  return (
    <div className="min-h-screen font-sans flex flex-col transition-colors duration-300">
      <Navbar setViewState={setViewState} isDark={isDark} toggleTheme={toggleTheme} />
      
      {/* Error Toast */}
      {error && (
        <div className="fixed top-20 right-4 z-50 bg-red-100 dark:bg-red-900 border-2 border-black dark:border-white p-4 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] dark:shadow-[4px_4px_0px_0px_rgba(255,255,255,1)] max-w-sm">
          <h4 className="font-bold text-red-600 dark:text-red-300 mb-1">Error</h4>
          <p className="text-sm dark:text-white">{error}</p>
          <button onClick={() => setError(null)} className="absolute top-1 right-1 font-bold text-xs px-2 hover:bg-red-200 dark:hover:bg-red-800 dark:text-white">X</button>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col">
        {viewState === ViewState.HOME && (
          <Home 
            setViewState={setViewState} 
            onLoadProject={handleLegacyLoad} 
            onUploadImage={handleUploadImage}
            isProcessing={isProcessing}
          />
        )}
        
        {viewState === ViewState.CONFIG && (
          <Configuration 
            setViewState={setViewState} 
            onGenerate={handleGenerate} 
            isGenerating={isProcessing}
          />
        )}

        {viewState === ViewState.DASHBOARD && (
          <Dashboard 
            plan={generatedPlan} 
            setViewState={setViewState} 
            onSave={handleSaveProject}
          />
        )}

        {viewState === ViewState.PROJECTS && (
          <Projects 
            setViewState={setViewState}
            onLoadProject={handleLoadSavedProject}
          />
        )}

        {viewState === ViewState.DOCS && (
          <Documentation />
        )}
      </div>
    </div>
  );
}

export default App;