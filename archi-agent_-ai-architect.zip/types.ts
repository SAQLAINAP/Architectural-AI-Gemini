
export enum ViewState {
  HOME = 'HOME',
  CONFIG = 'CONFIG',
  DASHBOARD = 'DASHBOARD',
  PROJECTS = 'PROJECTS',
  DOCS = 'DOCS',
}

export enum BuildingType {
  RESIDENTIAL = 'Residential',
  COMMERCIAL = 'Commercial',
  MIXED_USE = 'Mixed Use',
}

export enum CulturalSystem {
  NONE = 'None',
  VASTU_GENERAL = 'General Vastu',
  VASTU_NORTH = 'North Indian Vastu',
  VASTU_SOUTH = 'South Indian Vastu',
  ISLAMIC = 'Islamic Beliefs',
  CHRISTIAN = 'Christian Beliefs',
}

export enum MunicipalCode {
  NATIONAL = 'National Building Code',
  BBMP = 'BBMP (Bengaluru)',
  BMC = 'BMC (Mumbai)',
  MCD = 'MCD (Delhi)',
}

export interface ProjectConfig {
  projectType: BuildingType;
  width: number;
  depth: number;
  requirements: string[];
  adjacency: string;
  culturalSystem: CulturalSystem;
  municipalCode: MunicipalCode;
}

export interface WallFeature {
  type: 'door' | 'window' | 'opening';
  wall: 'top' | 'bottom' | 'left' | 'right';
  position: number; // 0 to 1 normalized along the wall
  width: number; // meters
}

export interface Room {
  id: string;
  name: string;
  type: 'room' | 'circulation' | 'outdoor' | 'setback' | 'service';
  x: number; // in meters
  y: number; // in meters
  width: number; // in meters
  height: number; // in meters
  features: WallFeature[];
  guidance?: string; // Cultural/Furniture placement advice
}

export interface ComplianceItem {
  rule: string;
  status: 'PASS' | 'FAIL' | 'WARN';
  message: string;
  recommendation?: string;
}

export interface MaterialItem {
  material: string;
  quantity: string;
  unit: string;
  estimatedCost: number;
}

export interface GeneratedPlan {
  imageUrl?: string; // For uploaded plans
  designLog?: string[]; // AI's reasoning steps
  rooms: Room[]; // "Rooms" now encompasses all zones. Can be empty if analyzing an image without geometry extraction.
  totalArea: number;
  builtUpArea: number;
  plotCoverageRatio: number;
  compliance: {
    regulatory: ComplianceItem[];
    cultural: ComplianceItem[];
  };
  bom: MaterialItem[];
  totalCostRange: {
    min: number;
    max: number;
  };
}

export interface SavedProject {
  id: string;
  name: string;
  date: string;
  config: ProjectConfig | null;
  plan: GeneratedPlan;
}