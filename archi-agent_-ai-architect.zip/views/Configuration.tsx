import React, { useState } from 'react';
import { NeoButton, NeoCard, NeoInput, NeoSelect } from '../components/NeoComponents';
import { BuildingType, CulturalSystem, MunicipalCode, ProjectConfig, ViewState } from '../types';
import { ArrowLeft, Sparkles, Plus, Trash2 } from 'lucide-react';

interface ConfigurationProps {
  setViewState: (state: ViewState) => void;
  onGenerate: (config: ProjectConfig) => void;
  isGenerating: boolean;
}

const Configuration: React.FC<ConfigurationProps> = ({ setViewState, onGenerate, isGenerating }) => {
  // Initial state
  const [projectType, setProjectType] = useState<BuildingType>(BuildingType.RESIDENTIAL);
  const [width, setWidth] = useState(12); // meters
  const [depth, setDepth] = useState(18); // meters
  const [requirements, setRequirements] = useState<string[]>(["Master Bedroom", "Kitchen", "Living Room", "Dining Area", "Common Bathroom"]);
  const [newReq, setNewReq] = useState("");
  const [adjacency, setAdjacency] = useState("Kitchen near Dining. Living facing North.");
  const [culturalSystem, setCulturalSystem] = useState<CulturalSystem>(CulturalSystem.VASTU_GENERAL);
  const [municipalCode, setMunicipalCode] = useState<MunicipalCode>(MunicipalCode.BBMP);

  const handleAddReq = () => {
    if (newReq.trim()) {
      setRequirements([...requirements, newReq.trim()]);
      setNewReq("");
    }
  };

  const handleRemoveReq = (index: number) => {
    setRequirements(requirements.filter((_, i) => i !== index));
  };

  const handleGenerate = () => {
    onGenerate({
      projectType,
      width,
      depth,
      requirements,
      adjacency,
      culturalSystem,
      municipalCode,
    });
  };

  return (
    <div className="max-w-5xl mx-auto p-6">
      <div className="flex items-center gap-4 mb-8">
        <NeoButton onClick={() => setViewState(ViewState.HOME)} variant="secondary" className="px-3">
          <ArrowLeft size={20} />
        </NeoButton>
        <h1 className="text-4xl font-black">CONFIGURE PROJECT</h1>
      </div>

      <div className="grid lg:grid-cols-2 gap-8">
        {/* Left Column: Physical Constraints */}
        <div className="space-y-6">
          <NeoCard className="bg-white">
            <h2 className="text-2xl font-black mb-4 bg-black text-white inline-block px-2">1. SCOPE</h2>
            <div className="space-y-4">
              <NeoSelect 
                label="Project Type"
                options={Object.values(BuildingType)}
                value={projectType}
                onChange={(e) => setProjectType(e.target.value as BuildingType)}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <NeoInput 
                  label="Plot Width (m)" 
                  type="number" 
                  value={width} 
                  onChange={(e) => setWidth(Number(e.target.value))} 
                />
                <NeoInput 
                  label="Plot Depth (m)" 
                  type="number" 
                  value={depth} 
                  onChange={(e) => setDepth(Number(e.target.value))} 
                />
              </div>

              <div>
                <label className="font-bold text-sm block mb-1">Room Requirements</label>
                <div className="flex gap-2 mb-2">
                  <input 
                    className="flex-1 bg-white border-2 border-black p-2 focus:outline-none"
                    value={newReq}
                    onChange={(e) => setNewReq(e.target.value)}
                    placeholder="e.g. Puja Room"
                    onKeyDown={(e) => e.key === 'Enter' && handleAddReq()}
                  />
                  <button onClick={handleAddReq} className="bg-black text-white p-2 hover:bg-gray-800">
                    <Plus size={20} />
                  </button>
                </div>
                <div className="flex flex-wrap gap-2">
                  {requirements.map((req, i) => (
                    <span key={i} className="bg-gray-200 border border-black px-2 py-1 text-sm flex items-center gap-1 font-medium">
                      {req}
                      <Trash2 size={12} className="cursor-pointer hover:text-red-600" onClick={() => handleRemoveReq(i)}/>
                    </span>
                  ))}
                </div>
              </div>
              
              <div>
                 <label className="font-bold text-sm block mb-1">Adjacency & Orientation</label>
                 <textarea 
                    className="w-full h-24 bg-white border-2 border-black p-3 focus:outline-none shadow-inner resize-none"
                    value={adjacency}
                    onChange={(e) => setAdjacency(e.target.value)}
                 />
              </div>
            </div>
          </NeoCard>
        </div>

        {/* Right Column: Rules & Regulations */}
        <div className="space-y-6">
          <NeoCard className="bg-pink-50">
            <h2 className="text-2xl font-black mb-4 bg-neo-secondary text-black inline-block px-2">2. CULTURE</h2>
            <div className="space-y-4">
               <NeoSelect 
                label="Belief System / Tuning"
                options={Object.values(CulturalSystem)}
                value={culturalSystem}
                onChange={(e) => setCulturalSystem(e.target.value as CulturalSystem)}
              />
              <p className="text-sm border-l-2 border-black pl-2 italic">
                The AI will prioritize layouts that conform to the cardinal directions and quadrant rules of the selected system.
              </p>
            </div>
          </NeoCard>

          <NeoCard className="bg-blue-50">
            <h2 className="text-2xl font-black mb-4 bg-neo-accent text-black inline-block px-2">3. COMPLIANCE</h2>
            <div className="space-y-4">
               <NeoSelect 
                label="Municipal Authority"
                options={Object.values(MunicipalCode)}
                value={municipalCode}
                onChange={(e) => setMunicipalCode(e.target.value as MunicipalCode)}
              />
              <p className="text-sm border-l-2 border-black pl-2 italic">
                Checks for Setbacks, Floor Area Ratio (FAR), and Minimum dimensions based on local by-laws.
              </p>
            </div>
          </NeoCard>

          <div className="pt-8">
            <NeoButton 
              onClick={handleGenerate} 
              className="w-full text-xl py-6 bg-black text-white hover:bg-gray-800 hover:text-white border-black"
              disabled={isGenerating}
            >
              {isGenerating ? (
                <span className="animate-pulse">Thinking...</span>
              ) : (
                <>
                  <Sparkles size={24} className="text-yellow-400" /> GENERATE PLANS
                </>
              )}
            </NeoButton>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Configuration;